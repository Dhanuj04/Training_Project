package com.springboot.Discountms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscountMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
